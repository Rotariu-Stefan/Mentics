package com.mentics.quip.nebula;
import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;
import com.mentics.quip.nebula.ActionResolver;
import com.mentics.quip.nebula.QuipNebula;


public class DesktopLauncher implements ActionResolver {
    private static DesktopLauncher launcher;

    public static void main(String args[]) {
        LwjglApplicationConfiguration cfg = new LwjglApplicationConfiguration();

        cfg.title = "Quip Nebula";
        cfg.width = 1280;
        cfg.height = 720;

        launcher = new DesktopLauncher();
        new LwjglApplication(launcher.game, cfg);
    }

    private QuipNebula game;

    public DesktopLauncher() {
        game = new QuipNebula(this);
    }
}

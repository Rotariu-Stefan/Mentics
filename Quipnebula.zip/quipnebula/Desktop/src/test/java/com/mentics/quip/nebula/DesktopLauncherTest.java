package com.mentics.quip.nebula;

import org.junit.Test;


public class DesktopLauncherTest {
    @Test
    public void test() {
        // TODO
    }
}

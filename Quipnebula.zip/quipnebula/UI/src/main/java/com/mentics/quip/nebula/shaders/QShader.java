package com.mentics.quip.nebula.shaders;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g3d.Renderable;
import com.badlogic.gdx.graphics.g3d.Shader;
import com.badlogic.gdx.graphics.g3d.utils.RenderContext;
import com.badlogic.gdx.graphics.g3d.utils.TextureDescriptor;
import com.badlogic.gdx.graphics.glutils.ShaderProgram;
import com.badlogic.gdx.utils.GdxRuntimeException;


public class QShader implements Shader {
    ShaderProgram program;
    private Camera camera;
    private RenderContext context;
    private int u_projViewTrans;
    private int u_worldTrans;
    private int u_albedoMap;
    private TextureDescriptor<Texture> textureDescription;
    private int u_viewerPos;

    public QShader(final Texture texture) {
        textureDescription = new TextureDescriptor<Texture>();
        textureDescription.texture = texture;
    }

    @Override
    public void init() {
        String vert = Gdx.files.internal("shaders/tvert-shader.glsl").readString();
        String frag = Gdx.files.internal("shaders/tfrag-shader.glsl").readString();
        program = new ShaderProgram(vert, frag);
        if (!program.isCompiled()) throw new GdxRuntimeException(program.getLog());
        u_projViewTrans = program.getUniformLocation("u_projViewTrans");
        u_worldTrans = program.getUniformLocation("u_worldTrans");
        u_albedoMap = program.getUniformLocation("u_albedoMap");
        u_viewerPos = program.getUniformLocation("u_viewerPos");
    }

    @Override
    public void begin(Camera camera, RenderContext context) {
        this.camera = camera;
        this.context = context;
        context.setCullFace(GL20.GL_BACK);
        context.setDepthTest(GL20.GL_LEQUAL);
        context.setDepthMask(true);

        int unit = context.textureBinder.bind(textureDescription);
        program.begin();
        program.setUniformi(u_albedoMap, unit);
        program.setUniformMatrix(u_projViewTrans, camera.combined);
        program.setUniformf(u_viewerPos, camera.position);
    }

    @Override
    public void render(Renderable renderable) {
        program.setUniformMatrix(u_worldTrans, renderable.worldTransform);
        renderable.mesh.render(program, renderable.primitiveType, renderable.meshPartOffset, renderable.meshPartSize);
    }

    @Override
    public void end() {
        program.end();
    }

    @Override
    public void dispose() {
        program.dispose();
    }

    @Override
    public boolean canRender(Renderable arg0) {
        return true;
    }

    @Override
    public int compareTo(Shader arg0) {
        return 0;
    }
}

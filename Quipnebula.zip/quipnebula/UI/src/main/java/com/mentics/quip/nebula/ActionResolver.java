package com.mentics.quip.nebula;

/**
 * Created by star on 2014-11-04.
 */
public interface ActionResolver {

}

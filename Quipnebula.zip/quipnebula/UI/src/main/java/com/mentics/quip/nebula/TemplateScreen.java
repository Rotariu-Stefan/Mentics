package com.mentics.quip.nebula;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.scenes.scene2d.Stage;

public class TemplateScreen implements Screen{
    protected final QuipNebula game;
    protected final Stage stage;

    public TemplateScreen(QuipNebula game){
        this.game=game;
        stage=new Stage(game.viewport,game.batch);
    }

    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
    }

	@Override
	public void render(float delta) {
        stage.act(delta);
        stage.draw();
	}

	@Override
	public void resize(int arg0, int arg1) {
        stage.getViewport().update(arg0,arg1,true);
	}

	@Override
	public void hide() {	}

	@Override
	public void dispose() {
		stage.dispose();
		
	}
	@Override
	public void pause() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void resume() {
		// TODO Auto-generated method stub
		
	}

}

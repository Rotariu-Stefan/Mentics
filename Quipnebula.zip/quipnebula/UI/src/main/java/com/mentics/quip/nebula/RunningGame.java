package com.mentics.quip.nebula;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.function.Supplier;

import com.mentics.quip.nebula.ai.AI;
import com.mentics.quip.nebula.audio.Audio;
import com.mentics.quip.nebula.model.Model;
import com.mentics.quip.nebula.model.ModelAction;
import com.mentics.quip.nebula.model.TimeSpeedEvent;
import com.mentics.thread.Pausable;


public class RunningGame {
    /**
     * TODO: send time control events to this queue
     */
    private Queue<ModelAction> modelQueue;

    private Main main;

    private Audio audio;

    private Worker worker;

    /**
     * TODO: when different conversations are highlighted, send ActiveSaidEvent event to AI
     */
    private AI ai;

    private ConcurrentLinkedQueue<UIRefreshEvent> uiQueue;


    // Constructors //

    public RunningGame(ConcurrentLinkedQueue<UIRefreshEvent> queue) {
        this.uiQueue = queue;
        setup();
    }


    // Public Methods //

    public Model getModel() {
        return main.getModel();
    }

    /**
     * Hook all the game stuff up
     */
    public void setup() {
        main = new Main();
        modelQueue = main.getQueue();

        audio = new Audio(); // Maybe pass it audio device or interface?
        audio.getQueue().add(AmbienceEvent.MAIN_MENU);

        Supplier<Model> modelSupplier = () -> main.getModel();
        worker = new Worker(modelSupplier, modelQueue);
        ai = new AI(modelSupplier, modelQueue, audio.getQueue());

        main.setup(uiQueue, new Pausable[] { worker.control(), ai.control() });
    }

    public void loadSkirmish() {
        load("skirmish");
    }

    public void loadStory() {
        load("story");
    }


    // Local Methods //

    protected void setTimeSpeed(float value) {
        // We can always just use one instance because if we ever had two on model queue, the first would be updated--so
        // more responsive.
        modelQueue.add(TimeSpeedEvent.instance(value));
    }

    /**
     * protected for access by testing
     */
    protected void load(String name) {
        main.resetGame();
        ai.load(name);
        // We want to start out "paused", but we need to process events (creating initial objects for example).
        // So we just have time speed set to very small number initially, so it's effectively paused.
        setTimeSpeed(1e-8f);
        main.resumeGame();
    }
}

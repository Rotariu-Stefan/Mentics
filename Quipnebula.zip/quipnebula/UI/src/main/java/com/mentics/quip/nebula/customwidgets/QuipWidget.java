package com.mentics.quip.nebula.customwidgets;

import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.mentics.quip.nebula.utils.Assets;

/**
 * Created by star on 2014-12-04.
 */
public abstract class QuipWidget extends Table {
	public interface QuipWidgetClickCallback{
		public void clicked(QuipWidget widget);
	}
    protected final Skin skin;
    private QuipWidgetClickCallback clickListener;

    public QuipWidget(){
    	if(Assets.skin==null)
    		System.err.print("Assets not loaded");
    	this.skin=Assets.skin;

        this.addListener(new InputListener() {
            @Override
            public boolean touchDown(InputEvent event, float x, float y, int pointer, int button) {
                if(clickListener!=null)
                	clickListener.clicked(QuipWidget.this);
                return true;
            }
        });
    }
    public abstract void handleKeyUp(int keyCode);

    public abstract void handleKeyDown(int keyCode);

    public void setActive(boolean active) {
        if(active)
            this.setBackground(skin.getDrawable("default-round-down"));
        else
            this.setBackground(skin.getDrawable("default-round"));
    }
    
    public void setListener(QuipWidgetClickCallback clickListener){
    	this.clickListener=clickListener;
    }
}

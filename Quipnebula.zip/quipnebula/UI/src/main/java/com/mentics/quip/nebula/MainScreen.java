package com.mentics.quip.nebula;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.PerspectiveCamera;
import com.badlogic.gdx.graphics.VertexAttributes.Usage;
import com.badlogic.gdx.graphics.g3d.Material;
import com.badlogic.gdx.graphics.g3d.Model;
import com.badlogic.gdx.graphics.g3d.ModelBatch;
import com.badlogic.gdx.graphics.g3d.ModelInstance;
import com.badlogic.gdx.graphics.g3d.attributes.BlendingAttribute;
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute;
import com.badlogic.gdx.graphics.g3d.utils.CameraInputController;
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.mentics.quip.nebula.customwidgets.QuipScroll;
import com.mentics.quip.nebula.customwidgets.QuipWidget;
import com.mentics.quip.nebula.customwidgets.QuipWidget.QuipWidgetClickCallback;
import com.mentics.quip.nebula.utils.Assets;

public class MainScreen extends TemplateScreen{

	private ModelBatch modelBatch;
	
	public final PerspectiveCamera camera;
	
	public final CameraInputController controller;
	
	public final ModelBuilder modelBuilder;

	private Model model;

	private ModelInstance instance;

	private Model modelSelected;

	private ModelInstance instanceSelected;
	
	private Table table;
	private QuipScroll events;
	private QuipScroll conversations;
	private QuipScroll says;
	private QuipScroll controls;
	private QuipScroll navigate;
	private QuipScroll groups;

    public QuipWidget activeWidget=null;

	private InputMultiplexer inputMultiplexer;
    
    public MainScreen(QuipNebula game) {
		super(game);

        modelBatch=new ModelBatch();
        modelBuilder=new ModelBuilder();
        
        camera=new PerspectiveCamera(67,Gdx.graphics.getWidth(),Gdx.graphics.getHeight());
        camera.position.set(10,10,10);
        camera.lookAt(0, 0, 0);
        camera.near=1f;
        camera.far=100f;
        camera.update();
        
        controller=new CameraInputController(camera);
        model=modelBuilder.createSphere(3, 3, 3,30, 30, new Material(ColorAttribute.createDiffuse(Color.TEAL)), Usage.Position|Usage.Normal);
        Material mat=new Material(ColorAttribute.createDiffuse(Color.PINK),new BlendingAttribute(0.5f));
        modelSelected=modelBuilder.createBox(4, 4, 4, mat, Usage.Position|Usage.Normal);
        instance=new ModelInstance(model);
        instanceSelected=new ModelInstance(modelSelected);
        
        inputMultiplexer=new InputMultiplexer();
        inputMultiplexer.addProcessor(stage);
        inputMultiplexer.addProcessor(controller);
        
        stage.addListener(new InputListener() {
        	
            public boolean keyDown(InputEvent event, int keycode) {
            	switch(keycode){
            	case Keys.Q:
            		setActiveWidget(events);
            		break;
            	case Keys.W:
            		setActiveWidget(conversations);
            		break;
            	case Keys.E:
            		setActiveWidget(says);
            		break;
            	case Keys.A:
            		setActiveWidget(controls);
            		break;
            	case Keys.S:
            		setActiveWidget(navigate);
            		break;
            	case Keys.Z:
            		setActiveWidget(groups);
            		break;
            	default:
            		if(activeWidget!=null)
            			activeWidget.handleKeyDown(keycode);
            	}
                return true;
            }
            
            public boolean keyUp(InputEvent event,int keyCode){
            	if(activeWidget!=null)
            		activeWidget.handleKeyUp(keyCode);
            	return true;
            }
            
        });
        
		table=new Table(Assets.skin);
		table.debug();
		table.setFillParent(true);
		stage.addActor(table);
		
		QuipWidgetClickCallback widgetListener=new QuipWidgetClickCallback(){
			@Override
			public void clicked(QuipWidget widget) {
				setActiveWidget(widget);				
			}
		};
		
		events=new QuipScroll("[Q] Events");
		conversations=new QuipScroll("[W] Conversations");
		says=new QuipScroll("[E] Say");
		controls=new QuipScroll("[A] Controls");
		navigate=new QuipScroll("[S] Navigation");
		groups=new QuipScroll("[Z] Groups");

		events.setListener(widgetListener);
		conversations.setListener(widgetListener);
		says.setListener(widgetListener);
		controls.setListener(widgetListener);
		navigate.setListener(widgetListener);
		groups.setListener(widgetListener);
		
		table.row().height(200f);
		
		table.add(events).pad(20).colspan(2).expandX().fill();
		table.add(conversations).pad(20).width(400).fill();
		table.add(says).pad(20).width(300).fill();
		
		table.row().height(200f);
		table.add(controls).pad(20).expandX().fill();
		table.add(navigate).pad(20).expandX().fill();
		
		table.row();
		table.add(groups).pad(20).colspan(2).expandX().fill();
		
	}

    public void setActiveWidget(QuipWidget widget){
    	if(activeWidget!=null)
    		activeWidget.setActive(false);
    	if(widget!=null) 
    		widget.setActive(true);
    	activeWidget=widget;
    }
    
    @Override
    public void show(){
    	super.show();
    	Gdx.input.setInputProcessor(inputMultiplexer);
    	setActiveWidget(null);
    }

    public void render(float v){
    	modelBatch.begin(camera);
    	modelBatch.render(instance);
    	modelBatch.render(instanceSelected);
    	modelBatch.end();
    	super.render(v);
    }

    @Override
    public void dispose(){
    	super.dispose();
    	model.dispose();
    	modelBatch.dispose();
    }
}

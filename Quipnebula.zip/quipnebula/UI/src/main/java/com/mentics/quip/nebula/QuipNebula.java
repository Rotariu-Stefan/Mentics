package com.mentics.quip.nebula;

import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.viewport.ExtendViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.bitfire.postprocessing.PostProcessor;
import com.bitfire.postprocessing.effects.Bloom;
import com.bitfire.utils.ShaderLoader;
import com.mentics.quip.nebula.model.GameEvent;
import com.mentics.quip.nebula.model.Model;
import com.mentics.quip.nebula.model.NavigationModel;
import com.mentics.quip.nebula.model.PlayerSayItem;
import com.mentics.quip.nebula.model.SaidItem;
import com.mentics.quip.nebula.utils.Assets;


public class QuipNebula extends Game {
    // Instance Fields //

    public final ActionResolver resolver;

    public SpriteBatch batch;
    public Viewport viewport;

    public PostProcessor postProcessor;

    public MainScreen mainScreen;

    private Test3D test3d;

    private MenuScreen menuScreen;

    protected Test3D testScreen;

    protected ConcurrentLinkedQueue<UIRefreshEvent> queue;

    private Model model;

    private RunningGame game;


    // Constructors //

    public QuipNebula(ActionResolver resolver) {
        this.resolver = resolver;
        this.queue = new ConcurrentLinkedQueue<>();
    }


    // Public Methods //

    @Override
    public void create() {
        batch = new SpriteBatch();
        viewport = new ExtendViewport(1280, 720);

        ShaderLoader.BasePath = "shaders/";

        postProcessor = new PostProcessor(true, true, true/*Gdx.app.getType==ApplicationType.Desktop*/);

        Bloom bloom = new Bloom((int)(Gdx.graphics.getWidth() * 0.25f), (int)(Gdx.graphics.getWidth() * 0.25f));

        postProcessor.addEffect(bloom);

        Assets.init();

        menuScreen = new MenuScreen(this);

        mainScreen = new MainScreen(this);

        testScreen = new Test3D(this);

        // setScreen(mainscreen);

        setScreen(menuScreen);

        game = new RunningGame(queue);
        model = game.getModel();
    }

    @Override
    public void render() {
        // TODO: handle refresh events
        if (model != null && queue.poll() != null) {
            // NOTE: We could do more fine grained refresh later, but for now, we'll reload all to demonstrate the API
            List<SaidItem<?>> spoken = model.getAllSaid();
            List<GameEvent> events = model.getGameEvents();
            // TODO: The relatedSayList is acquired by whatever is highlighted in the conversation panel
            List<PlayerSayItem> currentSayList = model.getCurrentSayList();
            // TODO: Update UI based on these
        }
        NavigationModel navModel = model.getNavigationModel();
        // TODO: render navigation based directly on model. Somewhere else it will update model occasionally

        Gdx.gl.glClearColor(0f, 0f, 0f, 0f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT);
        super.render();
    }

    @Override
    public void resize(int width, int height) {
        Gdx.gl.glViewport(0, 0, width, height);
        super.resize(width, height);
    }

    public void startSkirmish() {
        game.loadSkirmish();
        setScreen(mainScreen);
    }

    public void startStory() {
        game.loadStory();
        setScreen(mainScreen);
    }
}

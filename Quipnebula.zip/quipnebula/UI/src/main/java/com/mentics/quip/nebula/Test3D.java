package com.mentics.quip.nebula;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.PerspectiveCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.VertexAttributes.Usage;
import com.badlogic.gdx.graphics.g3d.Material;
import com.badlogic.gdx.graphics.g3d.Model;
import com.badlogic.gdx.graphics.g3d.ModelInstance;
import com.badlogic.gdx.graphics.g3d.Renderable;
import com.badlogic.gdx.graphics.g3d.attributes.BlendingAttribute;
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute;
import com.badlogic.gdx.graphics.g3d.attributes.TextureAttribute;
import com.badlogic.gdx.graphics.g3d.utils.CameraInputController;
import com.badlogic.gdx.graphics.g3d.utils.DefaultTextureBinder;
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder;
import com.badlogic.gdx.graphics.g3d.utils.RenderContext;
import com.badlogic.gdx.utils.Array;
import com.mentics.quip.nebula.shaders.QShader;
import com.mentics.quip.nebula.shaders.utils.RenderablePool;


public class Test3D extends TemplateScreen {

    public final PerspectiveCamera camera;

    public final CameraInputController controller;

    public final ModelBuilder modelBuilder;

    private Model model;

    private ModelInstance instance;

    private Model modelSelected;

    private ModelInstance instanceSelected;

    private Texture texture;

    private QShader qshader;

    private RenderContext rendercontext;

    private RenderablePool renderablePool;

    private Array<Renderable> renderables;


    public Test3D(QuipNebula game) {
        super(game);
        modelBuilder = new ModelBuilder();


        camera = new PerspectiveCamera(67, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        camera.position.set(10, 10, 10);
        camera.lookAt(0, 0, 0);
        camera.near = 1f;
        camera.far = 100f;
        camera.update();

        controller = new CameraInputController(camera);
        texture = new Texture("testimage.png");

        model =
                modelBuilder.createSphere(3, 3, 3, 30, 30, new Material(TextureAttribute.createDiffuse(texture)),
                        Usage.Position | Usage.Normal | Usage.TextureCoordinates);

        Material mat = new Material(ColorAttribute.createDiffuse(Color.PINK), new BlendingAttribute(0.5f));
        modelSelected = modelBuilder.createBox(4, 4, 4, mat, Usage.Position | Usage.Normal);
        instance = new ModelInstance(model);
        instanceSelected = new ModelInstance(modelSelected);

        Texture texture = new Texture("Graphics/lightningGrad.png");
        qshader = new QShader(texture);
        qshader.init();

        rendercontext = new RenderContext(new DefaultTextureBinder(DefaultTextureBinder.WEIGHTED, 1));

        renderablePool = new RenderablePool();

        renderables = new Array<Renderable>();
    }


    @Override
    public void show() {
        super.show();
        Gdx.input.setInputProcessor(controller);
    }

    public void render(float v) {
        System.out.println(camera.position);
        game.postProcessor.capture();
        rendercontext.begin();
        qshader.begin(camera, rendercontext);
        instance.getRenderables(renderables, renderablePool);
        for (Renderable renderable : renderables) {
            qshader.render(renderable);
        }
        qshader.end();
        renderablePool.freeAll(renderables);
        renderables.clear();
        rendercontext.end();

        game.postProcessor.render();
        super.render(v);
    }

    @Override
    public void dispose() {
        super.dispose();
        texture.dispose();
        model.dispose();
        qshader.dispose();
    }
}

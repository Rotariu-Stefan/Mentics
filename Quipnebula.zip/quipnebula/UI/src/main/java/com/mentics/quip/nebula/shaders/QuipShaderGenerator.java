package com.mentics.quip.nebula.shaders;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.g3d.Renderable;
import com.badlogic.gdx.graphics.g3d.Shader;
import com.badlogic.gdx.graphics.g3d.utils.BaseShaderProvider;
import com.mentics.quip.nebula.shaders.QuipShader.Config;

public class QuipShaderGenerator extends BaseShaderProvider{
	public final QuipShader.Config config;
	
	public QuipShaderGenerator(Config config) {
		this.config=(config==null) ?new QuipShader.Config():config;
	}

	public QuipShaderGenerator(final String vertexShader,final String fragmentShader){
		this(new QuipShader.Config(vertexShader, fragmentShader));
	}
	
	public QuipShaderGenerator(final FileHandle vertexShader,final FileHandle fragmentShader){
		this(vertexShader.readString(),fragmentShader.readString());
	}

	public QuipShaderGenerator(){
		this(null);
	}
	
	@Override
	protected Shader createShader(Renderable renderable) {
		Gdx.app.log("Quip Nebula","Generating Shader ("+shaders.size+")");
		return new QuipShader(renderable,config);
	}

}

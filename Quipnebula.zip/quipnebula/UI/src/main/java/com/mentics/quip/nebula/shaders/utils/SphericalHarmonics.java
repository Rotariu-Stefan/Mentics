package com.mentics.quip.nebula.shaders.utils;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g3d.Attribute;
import com.badlogic.gdx.graphics.g3d.environment.AmbientCubemap;
import com.badlogic.gdx.utils.GdxRuntimeException;

public class SphericalHarmonics extends Attribute{
	// <kalle_h> last term is no x*x * y*y but x*x - y*y
	private final static float coeff[] = {0.282095f, 0.488603f, 0.488603f, 0.488603f, 1.092548f, 1.092548f, 1.092548f, 0.315392f,
		0.546274f};
	
	public final static String Alias="sphericalHarmonics";
	public final static long Type=register(Alias);
	
	/*private final static float clamp (final float v) {
		return v < 0f ? 0f : (v > 1f ? 1f : v);
	}
*/
	public final float data[];

	public SphericalHarmonics () {
		super(Type);
		data = new float[9 * 3];
	}

	public SphericalHarmonics (final float copyFrom[]) {
		super(Type);
		if (copyFrom.length != (9 * 3)) throw new GdxRuntimeException("Incorrect array size");
		data = copyFrom.clone();
	}

	public final static boolean is(final long mask){
		return (mask & Type)!=0;
	}
	
	public SphericalHarmonics set (final float values[]) {
		for (int i = 0; i < data.length; i++)
			data[i] = values[i];
		return this;
	}

	public SphericalHarmonics set (final AmbientCubemap other) {
		return set(other.data);
	}

	public SphericalHarmonics set (final Color color) {
		return set(color.r, color.g, color.b);
	}

	public SphericalHarmonics set (float r, float g, float b) {
		for (int idx = 0; idx < data.length;) {
			data[idx++] = r;
			data[idx++] = g;
			data[idx++] = b;
		}
		return this;
	}

	@Override
	public Attribute copy() {
		return new SphericalHarmonics(this.data);
	}
	
	@Override
	protected boolean equals (Attribute other) {
		for(int i=0;i<data.length;i++){
			if(data[i]!=((SphericalHarmonics)other).data[i])
				return false;
		}
		return true;
	}
}
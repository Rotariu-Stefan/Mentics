package com.mentics.quip.nebula.customwidgets;

import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.List;
import com.badlogic.gdx.scenes.scene2d.ui.ScrollPane;
import com.badlogic.gdx.scenes.scene2d.utils.Align;


public class QuipScroll extends QuipWidget {
    private final List<String> list;
    private final ScrollPane scroll;
    private Label titlelbl;

    public QuipScroll() {
        this("");
    }

    public QuipScroll(String title) {
        list = new List<>(skin);
        scroll = new ScrollPane(list, skin);
        scroll.setOverscroll(false, false);
        scroll.setFadeScrollBars(false);

        titlelbl = new Label(title, skin, "assassin20");
        titlelbl.setAlignment(Align.center);
        this.add(titlelbl).padTop(10).fill().expandX();
        row();
        this.add(scroll).expand().fill().pad(10);

        list.setItems("How are you", "I am fine", "What about you?", "Great", "Good for you", "What the hell", "omg");
        this.setBackground(skin.getDrawable("default-round"));
    }


    public void setTitle(String title) {
        titlelbl.setText(title);
    }

    public void addItem(String string) {
        list.getItems().add(string);
    }

    @Override
    public void handleKeyUp(int keyCode) {

    }

    @Override
    public void handleKeyDown(int keyCode) {
        switch (keyCode) {
        case Keys.R:
            if (list.getItems().size > 0) {
                list.setSelectedIndex(0);
                scroll.scrollToCenter(0, (list.getItems().size - list.getSelectedIndex() - 1) * list.getItemHeight(),
                        100, list.getItemHeight());
            }
            break;
        case Keys.D:
            if (list.getSelectedIndex() > 0) {
                list.setSelectedIndex(list.getSelectedIndex() - 1);
                scroll.scrollToCenter(0, (list.getItems().size - list.getSelectedIndex() - 1) * list.getItemHeight(),
                        100, list.getItemHeight());
            }
            break;
        case Keys.F:
            if (list.getSelectedIndex() < list.getItems().size - 1) {
                list.setSelectedIndex(list.getSelectedIndex() + 1);
                scroll.scrollToCenter(0, (list.getItems().size - list.getSelectedIndex() - 1) * list.getItemHeight(),
                        100, list.getItemHeight());
            }
            break;

        case Keys.V:
            if (list.getItems().size > 0) {
                list.setSelectedIndex(list.getItems().size - 1);
                scroll.scrollToCenter(0, (list.getItems().size - list.getSelectedIndex() - 1) * list.getItemHeight(),
                        100, list.getItemHeight());
            }
            break;
        }
    }
}

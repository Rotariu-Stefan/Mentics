package com.mentics.quip.nebula.utils;

import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.assets.loaders.FileHandleResolver;
import com.badlogic.gdx.assets.loaders.SkinLoader;
import com.badlogic.gdx.assets.loaders.SkinLoader.SkinParameter;
import com.badlogic.gdx.assets.loaders.resolvers.InternalFileHandleResolver;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGeneratorLoader;
import com.badlogic.gdx.graphics.g2d.freetype.FreetypeFontLoader;
import com.badlogic.gdx.graphics.g2d.freetype.FreetypeFontLoader.FreeTypeFontLoaderParameter;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.utils.ObjectMap;

public class Assets {

	public static AssetManager assets=new AssetManager();
	
	public static Skin skin;
	
	private static FreeTypeFontLoaderParameter fontParams=new FreeTypeFontLoaderParameter();

	private static SkinParameter skinParams=new SkinLoader.SkinParameter("Skin/menu.atlas",new ObjectMap<String,Object>());
	
	private Assets(){}
	
	
	public static void init(){

		FileHandleResolver resolver = new InternalFileHandleResolver();
		assets.setLoader(FreeTypeFontGenerator.class, new FreeTypeFontGeneratorLoader(resolver));
		assets.setLoader(BitmapFont.class,".ttf", new FreetypeFontLoader(resolver));	
		
		loadFont("menuTitle","LuckiestGuy.ttf",50);
		loadFont("menuButton","ArchitectsDaughter.ttf",25);
		loadFont("assassin20","LuckiestGuy.ttf",25);
		
		assets.load("Skin/menuskin.json",Skin.class,skinParams);
    
        assets.finishLoading();
        
        skin=assets.get("Skin/menuskin.json",Skin.class);
	}
	
	public static void loadFont(String name,String fontfilename,int size){
		fontParams.fontFileName="Fonts/"+fontfilename;
		fontParams.fontParameters.size=size;
		assets.load(name+".ttf", BitmapFont.class, fontParams);
		assets.finishLoading();
		
		skinParams.resources.put(name,assets.get(name+".ttf",BitmapFont.class));
	}
}

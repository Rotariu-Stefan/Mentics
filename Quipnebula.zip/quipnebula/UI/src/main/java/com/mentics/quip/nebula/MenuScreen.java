package com.mentics.quip.nebula;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.mentics.quip.nebula.utils.Assets;


public class MenuScreen extends TemplateScreen {
    private final int menuButtonWidth = 330;
    private final int menuButtonHeight = 70;
    private final int menuButtonPad = 10;

    private Table table;
    private TextButton storyButton;
    private TextButton skirmishButton;
    private TextButton optionsButton;
    private TextButton exitButton;

    public MenuScreen(QuipNebula game) {
        super(game);

        table = new Table();
        table.setFillParent(true);
        stage.addActor(table);

        storyButton = new TextButton("Story", Assets.skin, "menuButton");
        storyButton.addListener(new ClickListener() {
            public void clicked(InputEvent event, float x, float y) {
                MenuScreen.this.game.setScreen(MenuScreen.this.game.testScreen);
            }
        });

        skirmishButton = new TextButton("Skirmish", Assets.skin, "menuButton");
        skirmishButton.addListener(new ClickListener() {
            public void clicked(InputEvent event, float x, float y) {
                MenuScreen.this.game.startSkirmish();
            }
        });

        optionsButton = new TextButton("Options", Assets.skin, "menuButton");
        exitButton = new TextButton("Exit", Assets.skin, "menuButton");
        exitButton.addListener(new ClickListener() {
            public void clicked(InputEvent event, float x, float y) {
                Gdx.app.exit();
            }
        });


        table.add(new Label("Quip Nebula", Assets.skin, "menuTitle")).padBottom(50);

        table.row();
        table.add(storyButton).width(menuButtonWidth).height(menuButtonHeight).pad(menuButtonPad);
        table.row();
        table.add(skirmishButton).width(menuButtonWidth).height(menuButtonHeight).pad(menuButtonPad);
        table.row();
        table.add(optionsButton).width(menuButtonWidth).height(menuButtonHeight).pad(menuButtonPad);
        table.row();
        table.add(exitButton).width(menuButtonWidth).height(menuButtonHeight).pad(menuButtonPad);

    }

}

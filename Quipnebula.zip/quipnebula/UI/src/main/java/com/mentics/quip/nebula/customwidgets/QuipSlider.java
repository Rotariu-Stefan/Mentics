package com.mentics.quip.nebula.customwidgets;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.scenes.scene2d.ui.Slider;


/**
 * Created by star on 2014-12-04.
 */
public class QuipSlider extends QuipWidget {
    private final Slider slider;

    private float nextValue;

    public QuipSlider(float min, float max, float stepSize, boolean vertical) {
        slider = new Slider(min, max, stepSize, vertical, skin);
        add(slider);
        this.setBackground(skin.getDrawable("default-round"));
    }

    @Override
    public void handleKeyUp(int keyCode) {

    }

    @Override
    public void handleKeyDown(int keyCode) {
        if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
            nextValue = slider.getValue() - slider.getStepSize() * Gdx.graphics.getDeltaTime() * 60;
            slider.setValue(nextValue > slider.getMinValue() ? nextValue : slider.getMinValue());
        } else if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {
            nextValue = slider.getValue() + slider.getStepSize();
            slider.setValue(nextValue < slider.getMaxValue() ? nextValue : slider.getMaxValue());
        }
    }

    @Override
    public void setActive(boolean active) {
        if (active) this.setBackground(skin.getDrawable("default-round-down"));
        else this.setBackground(skin.getDrawable("default-round"));
    }

}

package com.mentics.quip.nebula;

import static org.junit.Assert.*;

import java.util.concurrent.ConcurrentLinkedQueue;

import org.junit.Test;

import com.mentics.func.Affect1;
import com.mentics.lang.Value;
import com.mentics.quip.nebula.model.Model;
import com.mentics.quip.nebula.model.Navigable;


public class RunningGameTest {
    @Test
    public void test() throws Exception {
        try {
            ConcurrentLinkedQueue<UIRefreshEvent> queue = new ConcurrentLinkedQueue<>();
            RunningGame game = new RunningGame(queue);
            game.load("test");
            Thread.sleep(10);
            Model model = game.getModel();
            assertNotNull(model.getPlayer());
            Value<Integer> value = new Value<>(0);
            model.iterateNavItems(new Affect1<Navigable>() {
                @Override
                public void apply(Navigable a) {
                    value.value++;
                }
            });
            assertEquals(1, value.value.intValue());
        } finally {
            // Thread.sleep(1000);
        }
    }
}

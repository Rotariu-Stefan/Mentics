package com.mentics.math._float;

import static org.junit.Assert.*;

import org.junit.Test;

public class FloatUtilTest {

    @Test
    public void test() {
        fail("Not yet implemented");
    }

}

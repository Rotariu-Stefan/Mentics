package com.mentics.math._float;


public class FloatUtil {
    public static float EPS_CALC = 1e-5f;
    public static float DISTANCE_EPS = 1e-6f;

    public static boolean isSame(float f, float g) {
        return FloatUtil.isSame(f, g, EPS_CALC);
    }

    public static boolean isSame(float f, float g, float eps) {
        // return g == 0 ? Math.abs(f) < eps : ((f / g - 1) < eps); // GGGGGGGG
        return Math.abs(f - g) < eps || Math.abs(f / g - 1) < eps;
    }

    public static boolean isZero(float val) {
        return FloatUtil.isZero(val, EPS_CALC);
    }

    public static boolean isZero(float val, float eps) {
        return Math.abs(val) < eps;
    }

    public static boolean validAboveZero(float mag) {
        return !Float.isNaN(mag) && mag > DISTANCE_EPS;
    }

}

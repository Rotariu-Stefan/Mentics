package com.mentics.quip.nebula.model;

import java.util.List;


/**
 * Model for the UI to display the navigation panel. Each NavItem has an x, y centered around 0, 0. 0, 0 is always the
 * player and should be centered in the panel. x and y form a grid of where something should be shown representing that
 * item. The links should all be drawn as simple lines between the items.
 */
public class NavigationModel {
    public static class Link implements Comparable<Link> {
        public Positional i1;
        public Positional i2;
        public float distance;

        public Link(Positional i1, Positional i2, float distance) {
            this.i1 = i1;
            this.i2 = i2;
            this.distance = distance;
        }

        @Override
        public int compareTo(Link o) {
            return Float.compare(this.distance, o.distance);
        }
    }


    public static class NavLink {
        public NavItem i1;
        public NavItem i2;
        public float distance;

        public NavLink(NavItem i1, NavItem i2, float distance) {
            this.i1 = i1;
            this.i2 = i2;
            this.distance = distance;
        }
    }


    public static class NavItem {
        public int x;
        public int y;
        public Positional item;

        public NavItem(Positional item) {
            this.item = item;
        }

        public boolean equals(Object other) {
            return ((NavItem)other).item == this.item;
        }
    }


    List<NavItem> items;

    List<NavLink> links;

    public NavigationModel(List<NavItem> items, List<NavLink> links) {
        this.items = items;
        this.links = links;
    }
}

package com.mentics.quip.nebula.model;

public interface Physical extends Positional {}

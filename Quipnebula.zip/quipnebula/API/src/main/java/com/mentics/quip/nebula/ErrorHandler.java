package com.mentics.quip.nebula;

public class ErrorHandler {
    public static void error(String message, Throwable t) {
        t.printStackTrace();
        // TODO
    }
}

package com.mentics.quip.nebula.model;

public class TimeSpeedEvent implements ModelAction {
    private static TimeSpeedEvent INSTANCE = new TimeSpeedEvent();

    private float value;

    public static TimeSpeedEvent instance(float value) {
        INSTANCE.value = value;
        return INSTANCE;
    }

    @Override
    public void update(WriteModel model) {
        model.setDurationPerTick(value);
    }
}

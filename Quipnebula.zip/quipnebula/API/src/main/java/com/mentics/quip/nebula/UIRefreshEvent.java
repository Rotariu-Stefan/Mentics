package com.mentics.quip.nebula;

public interface UIRefreshEvent {

}

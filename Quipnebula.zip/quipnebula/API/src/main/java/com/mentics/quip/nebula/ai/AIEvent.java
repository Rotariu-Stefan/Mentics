package com.mentics.quip.nebula.ai;

public interface AIEvent {

}

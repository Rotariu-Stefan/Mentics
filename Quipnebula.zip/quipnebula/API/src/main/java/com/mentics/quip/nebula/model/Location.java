package com.mentics.quip.nebula.model;

public class Location implements Navigable {
    public final String name;
    public float[] position;

    public Location(String name, float[] position) {
        this.name = name;
        this.position = position;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public float[] getPosition() {
        return position;
    }
}

package com.mentics.quip.nebula.model;

public interface Positional {
    float[] getPosition();
}

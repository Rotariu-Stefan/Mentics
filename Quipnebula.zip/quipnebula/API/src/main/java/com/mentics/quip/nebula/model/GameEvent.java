package com.mentics.quip.nebula.model;

public class GameEvent {

}

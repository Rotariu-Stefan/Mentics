package com.mentics.quip.nebula.model;

/**
 * Something that was said by player in the game. Shows up in history of conversations.
 */
public class SaidItem<T extends PlayerSayItem> {
    /**
     * The quip who said it.
     */
    public final int quipId;

    public final T originalItem;

    public SaidItem(int quipId, T originalItem) {
        this.quipId = quipId;
        this.originalItem = originalItem;
    }
}

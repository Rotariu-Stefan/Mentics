package com.mentics.quip.nebula.model;

import java.util.List;

import com.mentics.func.Affect1;
import com.mentics.func.Affect2;


public interface Model {
    float getDurationPerTick();

    // Conversations Related //

    List<SaidItem<?>> getAllSaid();

    List<GameEvent> getGameEvents();

    List<PlayerSayItem> getCurrentSayList();


    // Navigation Related //

    NavigationModel getNavigationModel();

    /**
     * This does not include the current player controlled quip
     */
    void iterateNavItems(Affect1<Navigable> processor);

    /**
     * This does not include the current player controlled quip
     */
    void iterateNavItemPairs(Affect2<Navigable, Navigable> processor);

    /**
     * This does not include the current player controlled quip
     */
    void iterateCombatItemPairs(Affect2<Navigable, Navigable> processor);

    // Other //

    QuipRead getPlayer();
}

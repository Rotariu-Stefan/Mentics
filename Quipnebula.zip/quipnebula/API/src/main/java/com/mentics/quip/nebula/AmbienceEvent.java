package com.mentics.quip.nebula;

public interface AmbienceEvent {
    public static AmbienceEvent PAUSE = new AmbienceEvent() {};
    public static AmbienceEvent RESUME = new AmbienceEvent() {};
    public static AmbienceEvent MAIN_MENU = new AmbienceEvent() {};
}

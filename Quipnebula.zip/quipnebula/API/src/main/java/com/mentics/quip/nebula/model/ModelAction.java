package com.mentics.quip.nebula.model;

public interface ModelAction {
    void update(WriteModel model);
}

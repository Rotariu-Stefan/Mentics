package com.mentics.quip.nebula.model;

import java.util.List;


public class NpcSayItem extends PlayerSayItem {
    public final List<PlayerSayItem> relatedSayList;

    public NpcSayItem(String shortPhrase, String longPhrase, List<PlayerSayItem> list) {
        super(shortPhrase, longPhrase);
        this.relatedSayList = list;
    }
}

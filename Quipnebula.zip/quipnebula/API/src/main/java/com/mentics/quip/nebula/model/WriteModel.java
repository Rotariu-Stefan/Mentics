package com.mentics.quip.nebula.model;


public interface WriteModel extends Model {
    void setDurationPerTick(float newValue);

    void setPlayerQuip(String name);

    void createNewQuip(String name, float[] startingLocation);
}

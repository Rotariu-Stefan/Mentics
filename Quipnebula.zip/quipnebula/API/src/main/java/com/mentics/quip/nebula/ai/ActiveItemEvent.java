package com.mentics.quip.nebula.ai;

public class ActiveItemEvent implements AIEvent {

}

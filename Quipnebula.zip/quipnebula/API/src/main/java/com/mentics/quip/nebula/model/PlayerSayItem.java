package com.mentics.quip.nebula.model;


/**
 * This is something the user might say.
 */
public class PlayerSayItem {
    private String shortPhrase;
    private String longPhrase;


    public PlayerSayItem(String shortPhrase, String longPhrase) {
        this.shortPhrase = shortPhrase;
        this.longPhrase = longPhrase;
    }
}

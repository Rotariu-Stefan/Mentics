package com.mentics.quip.nebula.model;

public interface Navigable extends Positional {
    String getName();
}

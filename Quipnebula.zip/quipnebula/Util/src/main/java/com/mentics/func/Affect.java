package com.mentics.func;

public interface Affect {
    void affect();
}

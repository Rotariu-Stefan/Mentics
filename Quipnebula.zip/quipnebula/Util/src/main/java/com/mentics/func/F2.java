package com.mentics.func;

public interface F2<A, B, C> {
    A apply(B b, C c);
}

package com.mentics.func;



public interface Affect1<A> {
    void apply(A a);
}

package com.mentics.func;

public interface Affect2<A, B> {
    void apply(A a, B b);
}

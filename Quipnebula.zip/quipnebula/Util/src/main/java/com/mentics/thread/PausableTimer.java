package com.mentics.thread;

import java.util.Timer;
import java.util.TimerTask;

import com.mentics.func.Affect;


public class PausableTimer extends TimerTask implements Pausable {
    // Instance Fields //

    private Timer timer;
    private long period;
    private Affect onTick;
    private Affect onPause;
    private Affect onResume;


    // Constructors //

    public PausableTimer(long period, Affect onTick) {
        this(period, onTick, null, null);
    }

    public PausableTimer(long period, Affect onTick, Affect onPause, Affect onResume) {
        this.period = period;
        this.onTick = onTick;
        this.onPause = onPause;
        this.onResume = onResume;
    }


    // Public Methods //

    public void start() {
        resume();
    }

    /**
     * Does nothing if called multiple times without a resume in between.
     */
    @Override
    public void pause() {
        if (timer != null) {
            timer.cancel();
            timer = null;
            if (onPause != null) {
                onPause.affect();
            }
        }
    }

    /**
     * Does nothing if called multiple times without a pause in between.
     */
    @Override
    public void resume() {
        if (timer == null) {
            if (onResume != null) {
                onResume.affect();
            }
            timer = new Timer();
            timer.schedule(this, 0, period);
        }
    }

    @Override
    public void run() {
        onTick.affect();
    }
}

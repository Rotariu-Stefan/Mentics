package com.mentics.thread;

public interface Pausable {

    void pause();

    void resume();

}

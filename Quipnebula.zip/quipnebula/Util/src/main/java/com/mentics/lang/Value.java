package com.mentics.lang;

public class Value<T> {
    public T value;

    public Value(T value) {
        this.value = value;
    }
}

package com.mentics.quip.nebula.audio;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

import com.mentics.quip.nebula.AmbienceEvent;


public class Audio {
    protected ConcurrentLinkedQueue<AmbienceEvent> queue = new ConcurrentLinkedQueue<>();

    public Audio() {}

    public Queue<AmbienceEvent> getQueue() {
        return queue;
    }
}

package com.mentics.quip.nebula.ai;

import static com.mentics.math.vector.VectorUtil.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.mentics.func.Affect1;
import com.mentics.func.Affect2;
import com.mentics.quip.nebula.model.Model;
import com.mentics.quip.nebula.model.Navigable;
import com.mentics.quip.nebula.model.NavigationModel;
import com.mentics.quip.nebula.model.NavigationModel.Link;
import com.mentics.quip.nebula.model.NavigationModel.NavItem;
import com.mentics.quip.nebula.model.NavigationModel.NavLink;


/**
 * This algorithm is brute force and could be optimized a lot if needed. TODO: Needs a few representative tests
 */
public class UpdateNavModelAction {
    private Affect1<Navigable> playerProcessor = new Affect1<Navigable>() {
        @Override
        public void apply(Navigable item) {
            distances.add(new Link(player, item, distance2(player.getPosition(), item.getPosition())));
        }
    };

    private Affect2<Navigable, Navigable> processor = new Affect2<Navigable, Navigable>() {
        @Override
        public void apply(Navigable i1, Navigable i2) {
            distances.add(new Link(i1, i2, distance2(i1.getPosition(), i2.getPosition())));
        }
    };

    private List<Link> distances;

    private List<NavItem> items;
    private List<NavLink> links;

    private Navigable player;


    public UpdateNavModelAction() {}

    NavigationModel generateNavModel(Model model, NavType type) {
        // TODO: instantiate in constructor and just call clear each time. Until/unless we implement incremental which
        // might even be more optimized.
        distances = new ArrayList<>();
        items = new ArrayList<>();
        links = new ArrayList<>();

        // Handle player distance
        player = model.getPlayer();

        switch (type) {
        case NAV:
            model.iterateNavItems(playerProcessor);
            model.iterateNavItemPairs(processor);
        case COMBAT:
            model.iterateNavItems(playerProcessor);
            model.iterateCombatItemPairs(processor);
        }

        Collections.sort(distances);
        int len = distances.size();
        int numItems = 100; // TODO: calculate it from size of distances
        for (int i = 0; i < len; i++) {
            Link link = distances.get(i);
            boolean notFound = false;
            NavItem item1;
            NavItem item2;
            int index1 = items.indexOf(link.i1);
            if (index1 == -1) {
                item1 = new NavItem(link.i1);
                items.add(item1);
                notFound = true;
            } else {
                item1 = items.get(index1);
            }
            int index2 = items.indexOf(link.i2);
            if (index2 == -1) {
                item2 = new NavItem(link.i2);
                items.add(item2);
                index2 = items.size() - 1;
                notFound = true;
            } else {
                item2 = items.get(index2);
            }

            if (notFound) {
                links.add(new NavLink(item1, item2, link.distance));
                if (items.size() == numItems) {
                    break;
                }
            }
        }

        int playerIndex = items.indexOf(player);
        // TODO:

        NavItem item = items.get(playerIndex);
        item.x = 0;
        item.y = 0;
        setupChildren(item);

        return new NavigationModel(items, links);
    }

    private static int[][] dirs = { { 0, 1 }, { 1, 0 }, { 0, -1 }, { -1, 0 }, { 1, 1 }, { 1, -1 }, { -1, -1 },
                                   { -1, 1 } };

    private void setupChildren(NavItem item) {
        List<NavItem> children = linksFor(item);
        for (NavItem child : children) {
            for (int[] dir : dirs) {
                int x = item.x + dir[0];
                int y = item.y + dir[1];
                if (!isOccupied(x, y)) {
                    child.x = x;
                    child.y = y;
                    break;
                }
            }
        }
        for (NavItem child : children) {
            setupChildren(child);
        }
    }

    private List<NavItem> linksFor(NavItem item) {
        List<NavItem> result = new ArrayList<>();
        for (NavLink link : links) {
            if (link.i1 == item) {
                result.add(link.i2);
            }
        }
        return result;
    }

    private boolean isOccupied(int x, int y) {
        for (NavItem item : items) {
            if (item.x == x && item.y == y) {
                return true;
            }
        }
        return false;
    }
}

package com.mentics.quip.nebula.ai;

import com.mentics.quip.nebula.model.ModelAction;
import com.mentics.quip.nebula.model.WriteModel;


public class NewQuipAction implements ModelAction {
    private String name;
    private float[] startingLocation;

    public NewQuipAction(String name, float[] startingLocation) {
        this.name = name;
        this.startingLocation = startingLocation;
    }

    @Override
    public void update(WriteModel model) {
        model.createNewQuip(name, startingLocation);
    }
}

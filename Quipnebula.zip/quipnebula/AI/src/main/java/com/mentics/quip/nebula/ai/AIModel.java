package com.mentics.quip.nebula.ai;

import java.util.ArrayList;
import java.util.List;

import com.mentics.quip.nebula.model.ModelAction;


public class AIModel {
    public List<ModelAction> initial;

    public AIModel() {
        initial = new ArrayList<>();
    }
}

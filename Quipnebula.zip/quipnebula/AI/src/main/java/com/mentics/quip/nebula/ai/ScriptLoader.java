package com.mentics.quip.nebula.ai;

import java.io.IOException;
import java.io.InputStream;

import com.mentics.quip.nebula.ErrorHandler;


public class ScriptLoader {
    public static AIModel load(String name) {
        AIModel aiModel = new AIModel();
        ClassLoader loader = Thread.currentThread().getContextClassLoader();
        try (InputStream in = loader.getResourceAsStream("com/mentics/quip/nebula/script/" + name + "/root.csv")) {
            // TODO: load file into model
            if ("test".equals(name)) {
                // initially create 2 quips for testing
                aiModel.initial.add(new NewQuipAction("PlayerName", new float[] { 0, 0, 0 }));
                aiModel.initial.add(new NewQuipAction("OpponentName", new float[] { 0, 0, -100 }));
                aiModel.initial.add(new SetPlayerQuipAction("PlayerName"));
            }
        } catch (IOException e) {
            ErrorHandler.error("Could not load script: " + name, e);
        }
        return aiModel;
    }
}

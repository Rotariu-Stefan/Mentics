package com.mentics.quip.nebula.ai;

public enum NavType {
    NAV, COMBAT
}

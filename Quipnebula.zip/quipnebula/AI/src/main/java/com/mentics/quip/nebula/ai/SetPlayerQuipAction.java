package com.mentics.quip.nebula.ai;

import com.mentics.quip.nebula.model.ModelAction;
import com.mentics.quip.nebula.model.WriteModel;


public class SetPlayerQuipAction implements ModelAction {
    private String name;

    public SetPlayerQuipAction(String name) {
        this.name = name;
    }

    @Override
    public void update(WriteModel model) {
        model.setPlayerQuip(name);
    }
}

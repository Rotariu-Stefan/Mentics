package com.mentics.quip.nebula.ai;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.function.Supplier;

import com.mentics.quip.nebula.AmbienceEvent;
import com.mentics.quip.nebula.model.Model;
import com.mentics.quip.nebula.model.ModelAction;
import com.mentics.thread.Pausable;
import com.mentics.thread.PausableTimer;


public class AI {
    private static final long PERIOD = 100;

    // Instance Fields //

    /**
     * Reads from model for recognizing triggers and analyzing strategies and such
     */
    private Supplier<Model> modelSupplier;

    /**
     * Write modifications to the model here
     */
    private Queue<ModelAction> modelQueue;

    /**
     * Write changes to ambience here
     */
    private Queue<AmbienceEvent> ambienceQueue;

    private PausableTimer timer;

    private AIModel aiModel;

    private Queue<AIEvent> queue;


    // Constructors //

    public AI(Supplier<Model> modelSupplier, Queue<ModelAction> modelQueue, Queue<AmbienceEvent> ambienceQueue) {
        this.modelSupplier = modelSupplier;
        this.modelQueue = modelQueue;
        this.ambienceQueue = ambienceQueue;
        timer = new PausableTimer(PERIOD, this::onTick, this::onPause, this::onResume);
        queue = new ConcurrentLinkedQueue<>();
    }


    // Public Methods //

    public Pausable control() {
        return timer;
    }

    public void load(String name) {
        aiModel = ScriptLoader.load(name);
        // TODO: load scripting and push initial stuff to modelQueue
        modelQueue.addAll(aiModel.initial);
    }

    public void onPause() {
        ambienceQueue.add(AmbienceEvent.PAUSE);
    }

    public void onResume() {
        ambienceQueue.add(AmbienceEvent.RESUME);
    }

    public Queue<AIEvent> getQueue() {
        return queue;
    }

    public void onTick() {
        while (!queue.isEmpty()) {
            AIEvent event = queue.poll();
            // If it's an ActiveItemEvent, update model's currentSayList
        }

        // TODO: implement processing
    }
}

package com.mentics.quip.nebula.ai;

import org.junit.Test;


public class UpdateNavModelActionTest {
    @Test
    public void test() {
        // TOOD
    }
}

package com.mentics.quip.nebula;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

import com.mentics.quip.nebula.model.Energetic;
import com.mentics.quip.nebula.model.Model;
import com.mentics.quip.nebula.model.ModelAction;
import com.mentics.quip.nebula.model.NebulaModel;
import com.mentics.thread.Pausable;
import com.mentics.thread.PausableTimer;


/**
 * All things in this class run in a single thread.
 */
public class Main {
    /**
     * NOTE: Might change this to 1000/120 and just avoid running physics every other tick
     */
    private static final long PERIOD = 1000 / 60;

    // Instance Fields //

    private Queue<UIRefreshEvent> uiConsumer;
    private volatile NebulaModel model;
    protected ConcurrentLinkedQueue<ModelAction> queue;
    protected boolean paused = false;

    /**
     * If the game is to be paused, we pause all these modules also
     */
    private Pausable[] toPause;

    private PausableTimer timer;


    // Constructors //

    public Main() {
        this.timer = new PausableTimer(PERIOD, this::onTick);
        this.model = new NebulaModel();
        queue = new ConcurrentLinkedQueue<>();
    }

    // Public Methods //

    public void setup(Queue<UIRefreshEvent> uiConsumer, Pausable[] pausables) {
        this.uiConsumer = uiConsumer;
        this.toPause = pausables;
    }

    public Model getModel() {
        return model;
    }

    public Queue<ModelAction> getQueue() {
        return queue;
    }

    public void pauseGame() {
        for (Pausable p : toPause) {
            p.pause();
        }
        timer.pause();
    }

    public void resumeGame() {
        timer.resume();
        for (Pausable p : toPause) {
            p.resume();
        }
    }

    public void resetGame() {
        model = new NebulaModel();
        pauseGame();
    }

    public void onTick() {
        processQueue();
        updatePhysics();
        updateEnergy();
    }


    // Local Methods //

    private void processQueue() {
        while (!queue.isEmpty()) {
            ModelAction event = queue.poll();
            event.update(model);
        }
    }

    private void updatePhysics() {
        // TODO: update quips, orbs, shots
        // TODO: update camera
    }

    private void updateEnergy() {
        model.iterateEnergetic((Energetic energ) -> energ.updateEnergy(model.getDurationPerTick()));
    }
}

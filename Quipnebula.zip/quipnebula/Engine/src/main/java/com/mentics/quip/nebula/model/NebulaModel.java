package com.mentics.quip.nebula.model;

import java.util.ArrayList;
import java.util.List;

import com.mentics.func.Affect1;
import com.mentics.func.Affect2;


/**
 * This is the model for the whole game. Anything in here gets persisted in a save game, anything not in here does not.
 */
public class NebulaModel implements WriteModel {
    // Instance Fields //

    private float durationPerTick;

    private volatile Quip player;

    private Camera camera;

    /**
     * Includes player quip
     */
    private List<Quip> quips;

    private NavigationModel navModel;

    private List<GameEvent> gameEvents;

    // Updated by UI //
    private Positional activeItem; // What the user is currently interacting with

    // Updated by AI //
    private List<SaidItem<?>> allSaid;
    private List<PlayerSayItem> availableSayList;
    private List<PlayerSayItem> currentSayList;

    private List<Location> knownLocations;
    private List<Quip> knownQuips;


    // Constructors //

    public NebulaModel() {
        quips = new ArrayList<>();
        navModel = new NavigationModel(new ArrayList<>(), new ArrayList<>());
        gameEvents = new ArrayList<>();
        availableSayList = new ArrayList<>();
        allSaid = new ArrayList<>();
        knownLocations = new ArrayList<>();
        knownQuips = new ArrayList<>();
    }

    // Public Methods //

    @Override
    public float getDurationPerTick() {
        return durationPerTick;
    }

    @Override
    public void setDurationPerTick(float newValue) {
        this.durationPerTick = newValue;
    }


    // Converstation Related //

    @Override
    public List<SaidItem<?>> getAllSaid() {
        return allSaid;
    }

    @Override
    public List<GameEvent> getGameEvents() {
        return gameEvents;
    }

    @Override
    public List<PlayerSayItem> getCurrentSayList() {
        return currentSayList;
    }


    // Navigation Related //

    @Override
    public NavigationModel getNavigationModel() {
        return navModel;
    }

    @Override
    public void iterateNavItems(Affect1<Navigable> processor) {
        for (Quip quip : quips) {
            if (quip != player) {
                processor.apply(quip);
            }
        }
        for (Location loc : knownLocations) {
            processor.apply(loc);
        }
    }

    @Override
    public void iterateNavItemPairs(Affect2<Navigable, Navigable> processor) {
        // TODO Auto-generated method stub
    }

    @Override
    public void iterateCombatItemPairs(Affect2<Navigable, Navigable> processor) {
        // TODO Auto-generated method stub
    }


    // Other //

    @Override
    public QuipRead getPlayer() {
        return player;
    }

    public void iterateEnergetic(Affect1<Energetic> processor) {
        for (Quip q : quips) {
            processor.apply(q);
            for (Orb o : q.orbs) {
                processor.apply(o);
            }
        }
    }

    @Override
    public void setPlayerQuip(String name) {
        for (Quip q : quips) {
            if (name.equals(q.name)) {
                player = q;
                System.out.println("set player to: " + q);
                break;
            }
        }
    }

    @Override
    public void createNewQuip(String name, float[] startingLocation) {
        quips.add(new Quip(name, startingLocation));
    }
}

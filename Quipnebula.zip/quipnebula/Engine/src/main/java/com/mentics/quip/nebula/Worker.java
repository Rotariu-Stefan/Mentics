package com.mentics.quip.nebula;

import java.util.Queue;
import java.util.function.Supplier;

import com.mentics.quip.nebula.model.Model;
import com.mentics.quip.nebula.model.ModelAction;
import com.mentics.thread.Pausable;
import com.mentics.thread.PausableTimer;


public class Worker {
    private static long PERIOD = 1000 / 60;

    // Instance Methods //

    private Supplier<Model> modelSupplier;
    private Queue<ModelAction> modelQueue;
    private PausableTimer timer;

    private transient float durationPerTick;


    // Constructors //

    public Worker(Supplier<Model> model, Queue<ModelAction> modelQueue) {
        this.modelSupplier = model;
        this.modelQueue = modelQueue;
        timer = new PausableTimer(PERIOD, this::onTick);
    }


    // Public Methods //

    public Pausable control() {
        return timer;
    }

    public void onTick() {
        Model model = modelSupplier.get();
        durationPerTick = model.getDurationPerTick();
        avoidAndDetectCollisions();
        runControls();
        sendEvents();
        wakeThingsUp();
    }


    // Local Methods //

    private void avoidAndDetectCollisions() {
        // TODO Auto-generated method stub
    }

    private void runControls() {
        // TODO Auto-generated method stub
    }

    private void sendEvents() {
        // TODO Auto-generated method stub
    }

    private void wakeThingsUp() {
        // TODO Auto-generated method stub
    }
}

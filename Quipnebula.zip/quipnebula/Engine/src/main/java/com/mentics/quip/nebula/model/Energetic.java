package com.mentics.quip.nebula.model;


public interface Energetic {
    public final static float ENERGY_CONSUMPTION_PER_UNIT_MOMENTUM = 0.001f; // TODO: what should this be?

    /**
     * We pass in energy just in case we want to implement a non-linear recharge algorithm.
     */
    public static float updateEnergy(float energy, float max, float force, float generate, float duration) {
        energy -= ENERGY_CONSUMPTION_PER_UNIT_MOMENTUM * force * duration;
        energy += generate * duration;
        if (energy > max) {
            energy = max;
        }
        return energy;
    }

    float updateEnergy(float duration);
}

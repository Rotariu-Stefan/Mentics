package com.mentics.quip.nebula.model;

import static com.mentics.math.vector.VectorUtil.*;


public class Orb implements Energetic {
    private static float MAX_ENERGY = 10f;
    private static float ENERGY_GENERATION_PER_SECOND = 0.01f;

    // Instance Fields //

    public float energy;
    public PhysicalItem physical;


    // Public Methods //

    @Override
    public float updateEnergy(float duration) {
        energy =
                Energetic.updateEnergy(energy, MAX_ENERGY, magnitude(physical.acc) * physical.mass,
                        ENERGY_GENERATION_PER_SECOND, duration);
        return energy;
    }
}

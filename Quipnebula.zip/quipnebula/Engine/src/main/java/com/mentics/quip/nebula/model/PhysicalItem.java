package com.mentics.quip.nebula.model;



public class PhysicalItem implements Physical {
    public float pos[] = new float[3];
    public float vel[] = new float[3];
    public float acc[] = new float[3];

    public final float mass;
    private float radius;

    public PhysicalItem(float mass, float radius) {
        this.mass = mass;
        this.radius = radius;
    }

    @Override
    public float[] getPosition() {
        return pos;
    }
}

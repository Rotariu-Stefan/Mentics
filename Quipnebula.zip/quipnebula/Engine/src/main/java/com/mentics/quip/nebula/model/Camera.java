package com.mentics.quip.nebula.model;

import com.mentics.math.quaternion.Quaternion;


public class Camera extends PhysicalItem {
    public Camera() {
        super(0.1f, 0);
        // TODO Auto-generated constructor stub
    }

    Quaternion orientation;
    float[] angVel;
    float[] angAcc;
}

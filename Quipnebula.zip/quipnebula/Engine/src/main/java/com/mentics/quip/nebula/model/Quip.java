package com.mentics.quip.nebula.model;

import static com.mentics.math.vector.VectorUtil.*;

import java.util.ArrayList;
import java.util.List;

import com.mentics.math.vector.VectorUtil;


public class Quip implements QuipRead, Energetic {
    public final static float MAX_ENERGY = 100f;
    public final static float ENERGY_GENERATION_PER_SECOND = 0.02f;

    // Instance Fields //

    String name;
    float energy;
    List<Orb> orbs;
    PhysicalItem physical;


    // Constructors //

    public Quip(String name, float[] startingLocation) {
        this.name = name;
        orbs = new ArrayList<Orb>();
        physical = new PhysicalItem(0.1f, 1.0f);
        VectorUtil.set(physical.pos, startingLocation);
    }


    // Public Methods //

    @Override
    public String getName() {
        return name;
    }

    @Override
    public float[] getPosition() {
        return physical.pos;
    }

    @Override
    public float updateEnergy(float duration) {
        energy =
                Energetic.updateEnergy(energy, MAX_ENERGY, magnitude(physical.acc) * physical.mass,
                        ENERGY_GENERATION_PER_SECOND, duration);
        return energy;
    }
}

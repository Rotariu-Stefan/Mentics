package com.mentics.util;


public class Value<T> {
    public T value;
}

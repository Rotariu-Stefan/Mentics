package com.mentics.qd.ui.controls_custom;

import com.mentics.qd.ui.UIController_Hud;

public class LineController extends UIController_Hud {
	
	public void mouseClick() {
		System.out.println("LINE MOUSE CLICKED !!!");
	}
}
